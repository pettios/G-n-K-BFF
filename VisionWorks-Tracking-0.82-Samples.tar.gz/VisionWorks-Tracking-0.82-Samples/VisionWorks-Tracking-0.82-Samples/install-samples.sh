#!/bin/sh

#
# Copyright (c) 2015, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.
#

NVX_VERSION="1.4"
SAMPLES_DIR="VisionWorks-${NVX_VERSION}-Samples"

# Usage info

usage()
{
cat << EOF
usage: $0 [<target directory>]

This script installs the VisionWorks samples to <target directory>/$SAMPLES_DIR.
If the <target directory> option is missing, the current directory will be used.
EOF
}

if [ "$#" -gt 1 ]; then
    usage
    exit 1
fi

# Install

BASE_DIR="$(dirname "$0")"
TARGET_DIR="$1"

if [ -z "$TARGET_DIR" ]; then
    TARGET_DIR="$(pwd)"
    echo "No target directory specified, using the current directory: $TARGET_DIR"
fi

if [ ! -d "$TARGET_DIR" ]; then
    echo "Error: $TARGET_DIR is not a directory"
    usage
    exit 1
fi

if [ ! -w "$TARGET_DIR" ]; then
    echo "Error: You do not have permissions to write to $TARGET_DIR"
    usage
    exit 1
fi

TARGET_DIR="$TARGET_DIR/$SAMPLES_DIR"

echo "Creating the $TARGET_DIR directory..."
mkdir -p -- "$TARGET_DIR"

echo "Copying VisionWorks samples to $TARGET_DIR..."
cp -R -- "$BASE_DIR/"* "$TARGET_DIR/"
rm -- "$TARGET_DIR/install-samples.sh"

if [ -d "$BASE_DIR/../data" ]; then
    echo "Copying VisionWorks data to $TARGET_DIR..."
    cp -RT -- "$BASE_DIR/../data" "$TARGET_DIR/library-data"
fi

echo "Finished copying VisionWorks samples"

exit 0
